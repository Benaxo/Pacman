﻿using System.Collections.Generic;
using System.Drawing;

namespace Pacman
{
    public class ClassPacman
    {
        // Enumérations des directions
        public enum EnumPacDir
        {
            Die,
            Right,
            Left,
            Up,
            Down,
            None
        }

        // Les bitmaps du Pacman
        private List<Bitmap> ListPacLeft { get; set; }
        private List<Bitmap> ListPacRight { get; set; }
        private List<Bitmap> ListPacUP { get; set; }
        private List<Bitmap> ListPacDown { get; set; }
        private List<Bitmap> ListPacDie { get; set; }

        /// <summary>
        /// constructeur du Pacman
        /// </summary>
        public ClassPacman()
        {
            // Charge les images en ressources
            // Pacman left
            ListPacLeft = new List<Bitmap>()
            {
                Properties.Resources.PacNeutral,
                Properties.Resources.PacLeft01,
                Properties.Resources.PacLeft02,
                Properties.Resources.PacLeft03
            };
            // Pacman right
            ListPacRight = new List<Bitmap>()
            {
                Properties.Resources.PacNeutral,
                Properties.Resources.PacRight01,
                Properties.Resources.PacRight02,
                Properties.Resources.PacRight03
            };
            // Pacman up
            ListPacUP = new List<Bitmap>()
            {
                Properties.Resources.PacNeutral,
                Properties.Resources.PacUP01,
                Properties.Resources.PacUP02,
                Properties.Resources.PacUP03
            };
            // Pacman down
            ListPacDown = new List<Bitmap>()
            {
                Properties.Resources.PacNeutral,
                Properties.Resources.PacDown01,
                Properties.Resources.PacDown02,
                Properties.Resources.PacDown03
            };
            // Pacman Die
            ListPacDie = new List<Bitmap>()
            {
                Properties.Resources.PacDie1,
                Properties.Resources.PacDie2,
                Properties.Resources.PacDie3,
                Properties.Resources.PacDie4,
                Properties.Resources.PacDie5
            };
            // on enlève le fond du bitmap
            for (int i = 0; i <= 3; i++)
            {
                ListPacLeft[i].MakeTransparent(Color.Black);
                ListPacRight[i].MakeTransparent(Color.Black);
                ListPacUP[i].MakeTransparent(Color.Black);
                ListPacDown[i].MakeTransparent(Color.Black);
                ListPacDie[i].MakeTransparent(Color.Black);
            }
            ListPacDie[4].MakeTransparent(Color.Black);
        }

        /// <summary>
        /// Dessine le pacman
        /// </summary>
        /// <param name="Destination"></param>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <param name="Ani"></param>
        /// <param name="Dir"></param>
        public void DrawPacmanSprite(Graphics Destination, int X, int Y, int Ani, EnumPacDir Dir)
        {
            Bitmap BitmapPacman = null;
            if (Ani < 5)
            {
                switch (Dir)
                {
                    case EnumPacDir.Right:
                        BitmapPacman = new Bitmap(ListPacRight[Ani]);
                        break;
                    case EnumPacDir.Left:
                        BitmapPacman = new Bitmap(ListPacLeft[Ani]);
                        break;
                    case EnumPacDir.Up:
                        BitmapPacman = new Bitmap(ListPacUP[Ani]);
                        break;
                    case EnumPacDir.Down:
                        BitmapPacman = new Bitmap(ListPacDown[Ani]);
                        break;
                    case EnumPacDir.Die:
                        BitmapPacman = new Bitmap(ListPacDie[Ani]);
                        break;
                }
                Destination.DrawImage(BitmapPacman, new Rectangle(X, Y, 25, 25), 0, 0, 25, 25, GraphicsUnit.Pixel);
                BitmapPacman.Dispose();
            }
        }
    }
}
