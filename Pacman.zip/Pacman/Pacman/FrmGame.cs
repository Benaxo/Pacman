﻿using System.Windows.Forms;
using System.IO;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System;
using System.Diagnostics;

namespace Pacman
{
    public partial class FrmGame : Form
    {
        // Api
        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(Keys vKey);

        // int
        private int PacX, PacY;
        private int PacMapX, PacMapY;
        private int TimeScaler1;
        private int TimeScaler2;
        private int TimeScaler3;
        private int AnimatePacman;
        private int Score;
        private int HighScore;
        private int FlashPowerPill;
        private int PowerPillTimer;
        private int PillsEatenNumber;
        private int IntroTimer;
        private int ReleaseGhostsTimer;
        private int LivesNumber;
        private int PacDeadTimer;
        private int ShowGameOverTimer;
        private int GhostEatenSoundTimer;
        private int PacTitleX;
        private int CmovTitle = 2;

        // string
        private List<string> ListMapRows;
        private string FichHighScore;

        // bool 
        private bool Synchro;
        private bool GameOver = true;
        private bool ShowGameOver;
        private bool AppRunning = true;
        private bool NewGame;
        private bool FlashGhost;
        private bool PacMoving;
        private bool EatPowerPill;
        private bool ToggleEatSound;
        private bool DoIntro;
        private bool StartIntro;
        private bool PacDead;
        private bool PlayGhostEatenSound;

        // Buffer graphique
        private Bitmap ScrnBufferBmp;
        private Graphics GraphicsBuffer;

        // les bitmaps du jeu 
        private Bitmap Pill;
        private Bitmap PowerPill;
        private Bitmap Maze;
        private Bitmap MazeW;
        private Bitmap PacTitle;

        // Le pacman et les fantômes 
        private readonly ClassPacman Pacman = new ClassPacman();
        private List<ClassGhost> ListGhosts;

        // pour la direction du pacman (Right, Left, Up, Down, Die, None) 
        private ClassPacman.EnumPacDir PacDir;
        private ClassPacman.EnumPacDir PacMove;
        private ClassPacman.EnumPacDir NewDirection;

        // Sons 
        private readonly SoundPlayer Intro = new SoundPlayer(Properties.Resources.Intro);
        private readonly SoundPlayer EatPill1 = new SoundPlayer(Properties.Resources.PelletEat1);
        private readonly SoundPlayer EatPill2 = new SoundPlayer(Properties.Resources.PelletEat2);
        private readonly SoundPlayer PacEaten = new SoundPlayer(Properties.Resources.PacEaten);
        private readonly SoundPlayer GhostEaten = new SoundPlayer(Properties.Resources.GhostEaten);
        private readonly SoundPlayer Invinciblity = new SoundPlayer(Properties.Resources.Invincible);
        private readonly SoundPlayer Siren = new SoundPlayer(Properties.Resources.Siren);

        // Pour la détection des collisions
        private Rectangle GhostRect = new Rectangle();
        private Rectangle PacRect = new Rectangle();

        // les directions des fantômes
        private List<ClassGhost.EnumDirGhost> ListGhostDirs;

        public FrmGame()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Chargement de la form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmGame_Load(object sender, System.EventArgs e)
        {
            // charge les images en ressources
            PowerPill = Properties.Resources.PowerPill;
            Pill = Properties.Resources.Pill;
            Maze = Properties.Resources.Maze;
            MazeW = Properties.Resources.MazeW;
            PacTitle = Properties.Resources.PacTitle;
            // on enlève le fond : cela donne un sprite 
            Pill.MakeTransparent(Color.Black);
            PowerPill.MakeTransparent(Color.Black);
            PacTitle.MakeTransparent(Color.Black);
            // création d'un nouveau buffer graphique
            ScrnBufferBmp = new Bitmap(500, 600, CreateGraphics());
            GraphicsBuffer = Graphics.FromImage(ScrnBufferBmp);
            // double buffering
            SetStyle(ControlStyles.DoubleBuffer, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            // pour la détection des collisions
            PacRect.Size = new Size(16, 16);
            GhostRect.Size = new Size(16, 16);
        }

        /// <summary>
        /// Affichage de la form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmGame_Shown(object sender, System.EventArgs e)
        {
            // charge le score le plus haut sur le disque
            FichHighScore = Application.StartupPath + "HighScore.txt";
            LoadHighScore();
            // création des 4 directions des fantômes
            ListGhostDirs = new List<ClassGhost.EnumDirGhost>()
            {
                ClassGhost.EnumDirGhost.Right,
                ClassGhost.EnumDirGhost.Left,
                ClassGhost.EnumDirGhost.Up,
                ClassGhost.EnumDirGhost.Down
            };
            CreateGhosts();
            // boucle principal du jeu
            MainLoop();
        }

        /// <summary>
        /// création nouveaux fantômes
        /// </summary>
        private void CreateGhosts()
        {
            ListGhosts = new List<ClassGhost>()
            {
                new ClassGhost(212, 268, 14, 14, true, false),
                new ClassGhost(212, 268, 14, 14, false, false),
                new ClassGhost(212, 268, 14, 14, false, false),
                new ClassGhost(212, 268, 14, 14, true, false)
            };
        }

        /// <summary>
        /// boucle principale du jeu
        /// </summary>
        private void MainLoop()
        {
            while (AppRunning == true)
            {
                // Les 3 échelles de durée utilisées 
                TimeScaler1 = (TimeScaler1 + 1) % 3; // de 0 à 2
                TimeScaler2 = (TimeScaler2 + 1) % 10; // de 0 à 9
                TimeScaler3 = (TimeScaler3 + 1) % 25; // de 0 à 24
                // Traite la saisie clavier du joueur ( les 4 touches de direction et l'espace )
                ScanKeyboard();
                // Départ nouvelle partie
                if (NewGame == true)
                    InitGame();
                // Test si fin de partie
                if (GameOver == true)
                {
                    CheckForNewHighScore();
                    if (ShowGameOver == false)
                    {
                        GraphicsBuffer.FillRectangle(new SolidBrush(Color.Black), 0, 0, 500, 600);
                        ShowTitle();
                    }
                    else
                    {
                        // on affiche le Game over clignotant
                        ShowGameOverTimer += 1;
                        if (ShowGameOverTimer == 200)
                        {
                            ShowGameOver = false;
                            ShowGameOverTimer = 0;
                        }
                        // Routines principales du jeu 
                        MainCallsAtIdle();
                        // Flash "game over"
                        if (TimeScaler3 < 12)
                        {
                            DrawText(GraphicsBuffer, "GAME", 189, 260, 16, FontStyle.Bold, Brushes.Red);
                            DrawText(GraphicsBuffer, "OVER", 190, 280, 16, FontStyle.Bold, Brushes.Red);
                        }
                    }
                }
                else
                {
                    if (DoIntro == true)
                    // la partie commence
                    {
                        if (StartIntro == true)
                        {
                            // on joue l'introduction
                            Intro.Play();
                            StartIntro = false;
                            LoadHighScore();
                            ShowScores();
                        }
                        // Routines principales du jeu 
                        MainCallsAtIdle();
                        // Flash "get ready"
                        if (TimeScaler3 < 12)
                            DrawText(GraphicsBuffer, "Get Ready!", 168, 220, 14, FontStyle.Bold & FontStyle.Italic, Brushes.Red);
                        // l'introduction dure environ 5 secondes
                        IntroTimer += 1;
                        if (IntroTimer == 150)
                        {
                            Siren.PlayLooping();
                            DoIntro = false;
                            IntroTimer = 0;
                        }
                    }
                    else
                    {
                        // la partie est en cours 
                        if (TimeScaler1 == 2)
                        {
                            // Bascule synchro
                            Synchro = !Synchro;
                            if (PlayGhostEatenSound == true)
                            {
                                GhostEatenSoundTimer += 1;
                                if (GhostEatenSoundTimer == 10)
                                {
                                    GhostEatenSoundTimer = 0;
                                    PlayGhostEatenSound = false;
                                }
                            }
                            if (PacDead == false)
                            {
                                // Le Pacman est toujours en vie
                                WipeScoresAndLives();
                                ProcessInput();
                                DoPacman();
                                DoGhosts();
                                SreenRefresh();
                                CheckCollision();
                                ShowScores();
                                ShowLives();
                            }
                            else
                            {
                                // Pacman est mort: pause pour un moment, soustrait une vie et redémarre le jeu
                                SreenRefresh();
                                PacDeadTimer += 1;
                                PacDir = ClassPacman.EnumPacDir.Die;
                                if (PacDeadTimer < 10)
                                    AnimatePacman = 0;
                                else if (PacDeadTimer == 10)
                                {
                                    RegulatedDelay(100);
                                    AnimatePacman += 1;
                                    if (AnimatePacman == 5)
                                    {
                                        PacDeadTimer = 10;
                                        AnimatePacman = 5;
                                    }
                                    else
                                        PacDeadTimer = 9;
                                }
                                else if (PacDeadTimer > 25)
                                {
                                    AnimatePacman = 0;
                                    PacDead = false;
                                    LivesNumber -= 1;
                                    PacDeadTimer = 0;
                                    if (LivesNumber >= 0)
                                    {
                                        NewGame = true;
                                        Siren.PlayLooping();
                                    }
                                    else
                                    {
                                        GameOver = true;
                                        ShowGameOver = true;
                                    }
                                }
                            }
                        }
                    }
                }
                // Dessine le buffer écran sur l'écran actuel(appelle l'évènement Paint de la Form )
                Invalidate(new Rectangle(0, 0, 500, 600));
                // Délai 25 mS
                RegulatedDelay(25);
            }
            // fin de partie 
            Close();
        }

        /// <summary>
        /// Rafraîchit les bitmaps du plateau de jeu suite aux actions du joueur et aux déplacements des fantômes
        /// </summary>
        private void SreenRefresh()
        {
            RenderMaze(); // le labyrinthe
            RenderPills(); // les pillules
            RenderPac(); // le pacman
            RenderGhosts(); // les 4 fantômes
        }

        /// <summary>
        /// Initialisation du jeu
        /// </summary>
        private void InitGame()
        {
            // Charge la carte du jeu
            // . = Pillule
            // o = Pillule d'invincibilité
            // W = Mur ( Wall en anglais )
            // PP = position départ du Pacman
            ListMapRows = new List<string>()
            {
                "WWWWWWWWWWWWWWWWWWWWWWWWWWWW",
                "W............WW............W",
                "W.WWWW.WWWWW.WW.WWWWW.WWWW.W",
                "WoWWWW.WWWWW.WW.WWWWW.WWWWoW",
                "W.WWWW.WWWWW.WW.WWWWW.WWWW.W",
                "W..........................W",
                "W.WWWW.WW.WWWWWWWW.WW.WWWW.W",
                "W.WWWW.WW.WWWWWWWW.WW.WWWW.W",
                "W......WW....WW....WW......W",
                "WWWWWW.WWWWW WW WWWWW.WWWWWW",
                "     W.WWWWW WW WWWWW.W     ",
                "     W.WW          WW.W     ",
                "     W.WW WWWWWWWW WW.W     ",
                "WWWWWW.WW W      W WW.WWWWWW",
                "      .   W      W   .      ",
                "WWWWWW.WW W      W WW.WWWWWW",
                "     W.WW WWWWWWWW WW.W     ",
                "     W.WW          WW.W     ",
                "     W.WW WWWWWWWW WW.W     ",
                "WWWWWW.WW WWWWWWWW WW.WWWWWW",
                "W............WW............W",
                "W.WWWW.WWWWW.WW.WWWWW.WWWW.W",
                "W.WWWW.WWWWW.WW.WWWWW.WWWW.W",
                "Wo..WW.......PP.......WW..oW",
                "WWW.WW.WW.WWWWWWWW.WW.WW.WWW",
                "WWW.WW.WW.WWWWWWWW.WW.WW.WWW",
                "W......WW....WW....WW......W",
                "W.WWWWWWWWWW.WW.WWWWWWWWWW.W",
                "W.WWWWWWWWWW.WW.WWWWWWWWWW.W",
                "W..........................W",
                "WWWWWWWWWWWWWWWWWWWWWWWWWWWW"
            };
            // Création des 4 fantômes
            CreateGhosts();
            // réinitilisation des variables
            if (GameOver == true)
            {
                LivesNumber = 3;
                Score = 0;
            }
            PacX = 212;
            PacY = 414;
            PacMapX = 14;
            PacMapY = 23;
            PacDir = ClassPacman.EnumPacDir.Right;
            NewDirection = ClassPacman.EnumPacDir.Right;
            AnimatePacman = 3;
            Synchro = false;
            PillsEatenNumber = 0;
            ReleaseGhostsTimer = 0;
            GameOver = false;
            DoIntro = true;
            StartIntro = true;
            EatPowerPill = false;
            NewGame = false;
            Siren.Stop();
        }

        /// <summary>
        /// Décide quoi faire après les saisies directionnelles
        /// </summary>
        private void ProcessInput()
        {
            if (PacMapX < 28 & PacMapX > 1)
            {
                switch (PacMove)
                {
                    case ClassPacman.EnumPacDir.Right:
                        DirectionPacman(0, 1);
                        break;
                    case ClassPacman.EnumPacDir.Left:
                        DirectionPacman( 0, - 2);
                        break;
                    case ClassPacman.EnumPacDir.Up:
                        DirectionPacman(- 1, - 1);
                        break;
                    case ClassPacman.EnumPacDir.Down:
                        DirectionPacman( 1, - 1);
                        break;
                }
                PacMove = ClassPacman.EnumPacDir.None;
            }
        }

        /// <summary>
        /// Direction prise par le Pacman
        /// </summary>
        /// <param name="Ydeplacement"></param>
        /// <param name="Xdeplacement"></param>
        private void DirectionPacman(int Ydeplacement, int Xdeplacement) 
        {
            try
            {
                string MapString = ListMapRows[PacMapY + Ydeplacement].Substring(PacMapX + Xdeplacement, 1);
                NewDirection = MapString != "W" ? PacMove : PacDir;
            }
            catch
            {
            }
        }

        /// <summary>
        /// Gestion des fantômes
        /// </summary>
        private void DoGhosts()
        {
            Random AleaGhost = new Random(DateTime.Now.Millisecond);
            int GhostMapX, GhostMapY, GhostX, GhostY;
            ClassGhost.EnumDirGhost GhostDir;
            string MapString;
            ReleaseGhostsTimer = (ReleaseGhostsTimer + 1) % 13;
            for (int i = 0; i <= 3; i++)
            {
                // récupère les coordonnées
                GhostX = ListGhosts[i].GetX();
                GhostY = ListGhosts[i].GetY();
                GhostMapX = ListGhosts[i].GetMapX();
                GhostMapY = ListGhosts[i].GetMapY();
                GhostDir = ListGhosts[i].GetMoveDir();
                // relache les fantômes 1 par 1
                if (ListGhosts[i].IsActive() == false && ReleaseGhostsTimer == 12 && Synchro == false)
                {
                    GhostX = 204;
                    GhostY = 222;
                    GhostMapX = 14;
                    GhostMapY = 11;
                    ListGhosts[i].SetMoveDir(ListGhostDirs[AleaGhost.Next(0, 2)]); // pas de mouvement down car le fantôme est au centre
                    ListGhosts[i].SetActive(true);
                    ReleaseGhostsTimer = 0;
                }
                if (Synchro == false)
                {
                    if (EatPowerPill == false)
                        if (ListGhosts[i].IsActive() == true & ListGhosts[i].IsChaser() == true)
                            GhostDir = ListGhosts[i].Decide(ListMapRows, new Point(PacMapX, PacMapY));
                        else
                            // Abandon de la poursuite et déplacement opposé car le pacman a une pillule d'invincibilité
                            switch (PacDir)
                            {
                                case ClassPacman.EnumPacDir.Right:
                                    GhostDir = ClassGhost.EnumDirGhost.Left;
                                    break;
                                case ClassPacman.EnumPacDir.Left:
                                    GhostDir = ClassGhost.EnumDirGhost.Right;
                                    break;
                                case ClassPacman.EnumPacDir.Up:
                                    GhostDir = ClassGhost.EnumDirGhost.Down;
                                    break;
                                case ClassPacman.EnumPacDir.Down:
                                    GhostDir = ClassGhost.EnumDirGhost.Up;
                                    break;
                            }
                    // Valide nouveau mouvement ( s'assurer que le fantôme ne va pas dans le mur)
                    MapString = "W";
                    int Attemps = 0;
                    while (MapString == "W")
                    {
                        switch (GhostDir)
                        {
                            case ClassGhost.EnumDirGhost.Right:
                                MapString = ListMapRows[GhostMapY].Substring(GhostMapX, 1);
                                if (ListGhosts[i].IsActive() == true & GhostMapY == 14)
                                    MapString = "W";
                                break;
                            case ClassGhost.EnumDirGhost.Left:
                                MapString = ListMapRows[GhostMapY].Substring(GhostMapX - 2, 1);
                                if (ListGhosts[i].IsActive() == true & GhostMapY == 14)
                                    MapString = "W";
                                break;
                            case ClassGhost.EnumDirGhost.Up:
                                MapString = ListMapRows[GhostMapY - 1].Substring(GhostMapX - 1, 1);
                                break;
                            case ClassGhost.EnumDirGhost.Down:
                                MapString = ListMapRows[GhostMapY + 1].Substring(GhostMapX - 1, 1);
                                break;
                        }
                        // Si c'est un mur on teste un nouveau mouvement
                        if (MapString == "W")
                        {
                            if (ListGhosts[i].IsChaser() == false)
                                GhostDir = ListGhostDirs[AleaGhost.Next(0, 3)];
                            else
                            {
                                if (EatPowerPill == false)
                                {
                                    if (Attemps < 1)
                                    {
                                        if (GhostDir == ClassGhost.EnumDirGhost.Right | GhostDir == ClassGhost.EnumDirGhost.Left)
                                            GhostDir = GhostY > PacY ? ClassGhost.EnumDirGhost.Up : ClassGhost.EnumDirGhost.Down;
                                        else
                                            GhostDir = GhostX > PacX ? ClassGhost.EnumDirGhost.Left : ClassGhost.EnumDirGhost.Right;
                                    }
                                    else
                                        GhostDir = ListGhostDirs[AleaGhost.Next(0, 3)];
                                    Attemps += 1;
                                }
                                else
                                    GhostDir = ListGhostDirs[AleaGhost.Next(0, 3)];
                            }
                        }
                    }
                }
                // on applique le mouvement du fantôme
                switch (GhostDir)
                {
                    case ClassGhost.EnumDirGhost.Right:
                        GhostX += 8;
                        if (Synchro == true)
                            GhostMapX += 1;
                        break;
                    case ClassGhost.EnumDirGhost.Left:
                        GhostX -= 8;
                        if (Synchro == true)
                            GhostMapX -= 1;
                        break;
                    case ClassGhost.EnumDirGhost.Up:
                        GhostY -= 8;
                        if (Synchro == true)
                            GhostMapY -= 1;
                        break;
                    case ClassGhost.EnumDirGhost.Down:
                        GhostY += 8;
                        if (Synchro == true)
                            GhostMapY += 1;
                        break;
                }
                // applique les nouvelles coordonnées dans la classe 
                ListGhosts[i].SetMapX(GhostMapX);
                ListGhosts[i].SetMapY(GhostMapY);
                ListGhosts[i].SetX(GhostX);
                ListGhosts[i].SetY(GhostY);
                ListGhosts[i].SetMoveDir(GhostDir);
            }
        }

        /// <summary>
        /// Gestion des collisions entre les fantômes et le pacman  
        /// </summary>
        private void CheckCollision()
        {
            for (int i = 0; i <= 3; i++)
                if (ListGhosts[i].IsActive() == true)
                {
                    GhostRect.X = ListGhosts[i].GetX() + 8;
                    GhostRect.Y = ListGhosts[i].GetY() + 8;
                    Rectangle Overlap = Rectangle.Intersect(PacRect, GhostRect);
                    // si il y a une collision pacman-fantôme
                    if (Overlap.IsEmpty == false & Synchro == true)
                        if (EatPowerPill == true)
                        {
                            GhostEaten.Play();
                            PlayGhostEatenSound = true;
                            // 500 points pour avoir mangé un fantôme
                            Score += 500;
                            ListGhosts[i].SetShowPoints(true);
                            ListGhosts[i].SetPointsTimer(0);
                            ListGhosts[i].SetShowPointsX(ListGhosts[i].GetX());
                            ListGhosts[i].SetShowPointsY(ListGhosts[i].GetY() + 3);
                            ListGhosts[i].SetActive(false);
                            ListGhosts[i].SetX(204);
                            ListGhosts[i].SetY(268);
                            ListGhosts[i].SetMapX(14);
                            ListGhosts[i].SetMapY(14);
                            ReleaseGhostsTimer = 0;
                        }
                        else
                        {
                            PacDead = true;
                            Siren.Stop();
                            PacEaten.Play();
                        }
                }
        }

        /// <summary>
        /// Affiche les fantômes
        /// </summary>
        private void RenderGhosts()
        {
            int GhostColor, ShowPointsTimer;
            FlashGhost = !FlashGhost;
            for (int i = 0; i <= 3; i++)
            {
                // Fantôme en bleu si le joueur a une piluule d'invincibilité...
                GhostColor = EatPowerPill == true ? 4 : i;
                // Alterne couleur entre bleu et la couleur réelle du fantôme quand la durée en bleu est terminée
                if (PowerPillTimer > 50)
                    GhostColor = FlashGhost == false ? i : 4;
                // Affiche les fantômes
                ListGhosts[i].DrawGhostSprite(GraphicsBuffer, ListGhosts[i].GetMoveDir(), GhostColor);
                // Montre les points quelques secondes dès qu'un fantôme a été mangé
                if (ListGhosts[i].IsShowingPoints() == true)
                {
                    ShowPointsTimer = ListGhosts[i].GetPointsTimer();
                    ShowPointsTimer += 1;
                    ListGhosts[i].SetPointsTimer(ShowPointsTimer);
                    if (ShowPointsTimer < 25)
                        DrawText(GraphicsBuffer, "500", ListGhosts[i].GetPointsX(), ListGhosts[i].GetPointsY(), 10, FontStyle.Bold, Brushes.Red);
                    else
                        ListGhosts[i].SetShowPoints(false);
                }
            }
        }

        /// <summary>
        /// Gestion du pacman
        /// </summary>
        private void DoPacman()
        {
            if (Synchro == false)
                PacDir = NewDirection;
            AnimatePacman = PacMoving == true | PacDead == true ? (AnimatePacman + 1) % 4 : 3;
            if (PacDir == ClassPacman.EnumPacDir.Right && PacMapY == 14 && PacMapX == 28)
            {
                // le pacman sort à droite et rentre à gauche
                PacMapX = 1;
                PacX = 4;
            }
            else if (PacDir == ClassPacman.EnumPacDir.Left && PacMapY == 14 && PacMapX == 1)
            {
                // le pacman sort à gauche et rentre à droite
                PacMapX = 28;
                PacX = 420;
            }
            else
            {
                switch (PacDir)
                {
                    case ClassPacman.EnumPacDir.Right:
                        MovePacman(0, 0, 8, 0);
                        break;
                    case ClassPacman.EnumPacDir.Left:
                        MovePacman(0, -2, -8, 0);
                        break;
                    case ClassPacman.EnumPacDir.Up:
                        MovePacman(-1, -1, 0, -8);
                        break;
                    case ClassPacman.EnumPacDir.Down:
                        MovePacman(1, -1, 0, 8);
                        break;
                }
            }
            if (EatPowerPill == true)
            {
                PowerPillTimer += 1;
                if (PowerPillTimer == 85)
                {
                    EatPowerPill = false;
                    PowerPillTimer = 0;
                    Siren.PlayLooping();
                }
            }
            PacRect.X = PacX + 8;
            PacRect.Y = PacY + 8;
            bool Blink = false;
            // As-t'on mangé toutes les pillules
            if (PillsEatenNumber == 240)
            {
                for (int i = 1; i <= 10; i++)
                {
                    RenderMaze(Blink);
                    Invalidate(new Rectangle(0, 0, 500, 600));
                    RegulatedDelay(300);
                    Blink = true;
                }
                NewGame = true;
            }
        }

        /// <summary>
        /// Déplacement du Pacman
        /// </summary>
        /// <param name="Ydeplacement"></param>
        /// <param name="Xdeplacement"></param>
        /// <param name="IncPacX"></param>
        /// <param name="IncPacY"></param>
        private void MovePacman(int Ydeplacement, int Xdeplacement, int IncPacX, int IncPacY)
        {
            string MapString = ListMapRows[PacMapY].Substring(PacMapX - 1, 1);
            // Test si Pacman mange une pillule
            if (MapString == "." | MapString == "o")
                PacmanEat(MapString);
            MapString = ListMapRows[PacMapY + Ydeplacement].Substring(PacMapX + Xdeplacement, 1);
            PacMoving = MapString != "W";
            if (PacMoving == true)
            {
                // le pacman avance vers la gauche
                PacX += IncPacX;
                PacY += IncPacY;
                if (Synchro == true)
                {
                    PacMapX += IncPacX / 8;
                    PacMapY += IncPacY / 8;
                }
            }
        }

        /// <summary>
        /// Le pacman mange une pillule
        /// </summary>
        /// <param name="MapString"></param>
        private void PacmanEat(string MapString)
        {
            // on modifie la ligne de la map pour y faire figurer la pillule mangée : on la remplace par un espace
            ListMapRows[PacMapY] = ListMapRows[PacMapY].Remove(PacMapX - 1, 1).Insert(PacMapX - 1, " ");
            switch (MapString)
            {
                case ".": // pillule normale
                    Score += 100;
                    PillsEatenNumber += 1;
                    PlayEatenPillSnds();
                    break;
                case "o": // une des 4 pillules d'invincibilité
                    EatPowerPill = true;
                    PowerPillTimer = 0;
                    Invinciblity.PlayLooping();
                    break;
            }
        }

        /// <summary>
        /// joue un son lorsque le pacman mange des pillules
        /// </summary>
        private void PlayEatenPillSnds()
        {
            ToggleEatSound = !ToggleEatSound;
            if (PlayGhostEatenSound == false)
            {
                if (ToggleEatSound == false)
                    EatPill1.Play();
                else
                    EatPill2.Play();
            }
        }

        /// <summary>
        /// Gestion des pillules 
        /// </summary>
        private void RenderPills()
        {
            FlashPowerPill = (FlashPowerPill + 1) % 8;
            // Les pilulles d'invincibilité ne clignotent pas durant l'introduction ou lors du Game over
            if (DoIntro == true | ShowGameOver == true)
                FlashPowerPill = 0;
            for (int i = 1; i <= 28; i++)
                for (int j = 1; j <= 29; j++)
                    switch (ListMapRows[j].Substring(i - 1, 1))
                    {
                        case ".":
                            GraphicsBuffer.DrawImage(Pill, new Rectangle((i * 16) - 10, (j * 16) + 55, 6, 6), 0, 0, 6, 6, GraphicsUnit.Pixel);
                            break;
                        case "o":
                            if (FlashPowerPill < 4)
                                GraphicsBuffer.DrawImage(PowerPill, new Rectangle((i * 16) - 14, (j * 16) + 51, 14, 14), 0, 0, 14, 14, GraphicsUnit.Pixel);
                            break;
                    }
        }

        /// <summary>
        /// Affichage du labyrinthe
        /// </summary>
        /// <param name="RenderColorWhite"></param>
        private void RenderMaze(bool RenderColorWhite = false)
        {
            Bitmap MazeBitmap = RenderColorWhite == true ? new Bitmap(MazeW) : new Bitmap(Maze);
            GraphicsBuffer.DrawImage(MazeBitmap, new Rectangle(0, 50, 448, 496), 0, 0, 448, 496, GraphicsUnit.Pixel);
            MazeBitmap.Dispose();
        }

        /// <summary>
        /// Affichage du Pacman
        /// </summary>
        private void RenderPac()
        {
            Pacman.DrawPacmanSprite(GraphicsBuffer, PacX, PacY, AnimatePacman, PacDir);
        }

        /// <summary>
        /// Affichage de l'introduction
        /// </summary>
        private void ShowTitle()
        {
            int GhostColor;
            ClassPacman.EnumPacDir DirAnimation;
            GraphicsBuffer.DrawImage(PacTitle, new Rectangle(172, 101, 50, 50), 0, 0, 50, 50, GraphicsUnit.Pixel);
            for (int i = 0; i <= 3; i++)
                DrawText(GraphicsBuffer, "PA   MAN", 70 + i, 88 + i, 48, FontStyle.Bold, i == 0 ? Brushes.Yellow : Brushes.Green);
            Pen OpenPen = new Pen(Color.Cyan);
            GraphicsBuffer.DrawRectangle(OpenPen, 75, 93, 300, 90);
            OpenPen.Dispose();
            if (PacTitleX > 470)
                CmovTitle = -4;
            if (PacTitleX < 200)
                CmovTitle = 4;
            PacTitleX += CmovTitle;
            if (TimeScaler1 == 2)
                AnimatePacman = (AnimatePacman + 1) % 4;
            DirAnimation = CmovTitle > 0 ? ClassPacman.EnumPacDir.Right : ClassPacman.EnumPacDir.Left;
            GhostColor = CmovTitle > 0 ? 0 : 5;
            Pacman.DrawPacmanSprite(GraphicsBuffer, PacTitleX - 50, 200, AnimatePacman, DirAnimation);
            for (int i = 0; i <= 3; i++)
            {
                ListGhosts[i].SetX(PacTitleX - ((i + 3) * 30));
                ListGhosts[i].SetY(200);
                ListGhosts[i].DrawGhostSprite(GraphicsBuffer, ClassGhost.EnumDirGhost.Right, i + GhostColor);
            }
            Brush BrushColor = TimeScaler2 < 5 ? Brushes.Red : Brushes.Gold;
            DrawText(GraphicsBuffer, "Press Espace To Play", 143, 245, 14, FontStyle.Bold, BrushColor);
        }

        /// <summary>
        /// Affiche le nombre de vies restantes
        /// </summary>
        private void ShowLives()
        {
            for (int i = 0; i <= LivesNumber - 1; i++)
                GraphicsBuffer.DrawImage(PacTitle, new Rectangle((i * 35) + 5, 550, 25, 25), 0, 0, 50, 50, GraphicsUnit.Pixel);
        }

        /// <summary>
        /// Routines pricipales du jeu
        /// </summary>
        private void MainCallsAtIdle()
        {
            WipeScoresAndLives(); // efface les scores et les vies
            RenderMaze(); // affiche le labyrinthe
            RenderPills(); // affiche les pillules
            RenderPac(); // affiche le Pacman
            ShowScores(); // affiche les scores
            ShowLives(); // affiche les vies
        }

        /// <summary>
        /// Test pour voir si le record a été battu ( à faire à la fin de chaque partie)
        /// </summary>
        private void CheckForNewHighScore()
        {
            if (Score > HighScore)
            {
                HighScore = Score;
                ShowScores();
                SaveHighScore();
            }
        }

        /// <summary>
        /// Charge le record sur le disque
        /// </summary>
        private void LoadHighScore()
        {
            if (File.Exists(FichHighScore) == true)
            {
                // flux de lecture du plus haut score  
                StreamReader FileStreamReader = File.OpenText(FichHighScore);
                // lecture du plus haut score
                HighScore = Convert.ToInt32(FileStreamReader.ReadLine());
                // Ferme le flux de lecture  
                FileStreamReader.Close();
            }
            else
                HighScore = 0;
        }

        /// <summary>
        /// Sauvegarde du record sur le disque
        /// </summary>
        private void SaveHighScore()
        {
            // flux d'écriture du fichier
            FileStream FileStreamWriter = File.Create(FichHighScore);
            ASCIIEncoding Encoder = new ASCIIEncoding();
            string Str;
            byte[] Buffer;
            // Ecriture du plus haut score
            Str = HighScore.ToString() + Environment.NewLine;
            Buffer = new byte[Str.Length];
            Encoder.GetBytes(Str, 0, Str.Length, Buffer, 0);
            FileStreamWriter.Write(Buffer, 0, Buffer.Length);
            // Ferme le flux d'écriture
            FileStreamWriter.Close();
        }

        /// <summary>
        /// Affiche le score actuel et le record
        /// </summary>
        private void ShowScores()
        {
            for (int i = 0; i <= 1; i++)
            {
                DrawText(GraphicsBuffer, "SCORE: " + Score.ToString(), 275 + i, 10, 14, FontStyle.Regular, Brushes.White);
                DrawText(GraphicsBuffer, "HIGH SCORE: " + HighScore.ToString(), 40 + i, 10, 14, FontStyle.Regular, Brushes.Red);
            }
        }

        /// <summary>
        /// Affichage texte
        /// </summary>
        /// <param name="Destination"></param>
        /// <param name="Text"></param>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <param name="FontSize"></param>
        /// <param name="Style"></param>
        /// <param name="BrushCol"></param>    
        private void DrawText(Graphics Destination, string Text, int X, int Y, int FontSize, FontStyle Style, Brush BrushCol)
        {
            // Font et attributs spécifiques
            Font DrawFont = new Font("MS Sans Serif", FontSize, Style);
            StringFormat DrawFormat = new StringFormat { FormatFlags = StringFormatFlags.NoFontFallback };
            // Dessine le texte dans le buffer graphique
            Destination.DrawString(Text, DrawFont, BrushCol, X, Y, DrawFormat);
        }

        /// <summary>
        /// Saisie clavier des 4 flèches et de la touche Espace
        /// </summary>
        private void ScanKeyboard()
        {
            if (GetAsyncKeyState(Keys.Right) == 1 | GetAsyncKeyState(Keys.Right) == short.MinValue)
                PacMove = ClassPacman.EnumPacDir.Right;
            else if (GetAsyncKeyState(Keys.Left) == 1 | GetAsyncKeyState(Keys.Left) == short.MinValue)
                PacMove = ClassPacman.EnumPacDir.Left;
            else if (GetAsyncKeyState(Keys.Up) == 1 | GetAsyncKeyState(Keys.Up) == short.MinValue)
                PacMove = ClassPacman.EnumPacDir.Up;
            else if (GetAsyncKeyState(Keys.Down) == 1 | GetAsyncKeyState(Keys.Down) == short.MinValue)
                PacMove = ClassPacman.EnumPacDir.Down;
            else if (GetAsyncKeyState(Keys.Space) == 1 | GetAsyncKeyState(Keys.Space) == short.MinValue)
            {
                if (DoIntro == false & ShowGameOver == false)
                {
                    NewGame = true;
                    GameOver = true;
                }
            }
            else
                PacMove = ClassPacman.EnumPacDir.None;
        }

        /// <summary>
        /// Délai en millisecondes ( utilisé dans différentes procédures )
        /// </summary>
        /// <param name="Delay"></param>
        private void RegulatedDelay(int Delay)
        {
            Stopwatch Sw = new Stopwatch();
            Sw.Start();
            while (Sw.ElapsedMilliseconds < Delay)
                Application.DoEvents();
            Sw.Stop();
        }

        /// <summary>
        /// Efface les score et les vies à l'écran
        /// </summary>
        private void WipeScoresAndLives()
        {
            GraphicsBuffer.FillRectangle(new SolidBrush(Color.Black), 0, 0, 500, 50);
            GraphicsBuffer.FillRectangle(new SolidBrush(Color.Black), 0, 550, 500, 50);
        }

        /// <summary>
        /// Rafraîchissement écran
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmGame_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(ScrnBufferBmp, 0, 0);
        }

        /// <summary>
        /// A faire en fermant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmGame_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (AppRunning == true)
            {
                AppRunning = false;
                e.Cancel = true;
                SaveHighScore();
            }
        }

        /// <summary>
        /// A faire une fois l'application fermée
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmGame_FormClosed(object sender, FormClosedEventArgs e)
        {
            Dispose();
            Application.Exit();
        }
    }
}
