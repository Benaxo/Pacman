﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace Pacman
{
    public class ClassGhost
    {
        //Enumération des directions
        public enum EnumDirGhost
        {
            Right,
            Left,
            Up,
            Down
        }

        // Les bitmaps du fantôme
        private List<Bitmap> ListGhostLeft { get; set; }
        private List<Bitmap> ListGhostRight { get; set; }
        private List<Bitmap> ListGhostUP { get; set; }
        private List<Bitmap> ListGhostDown { get; set; }
        private Bitmap GhostBlue { get; set; }

        // Propriétés
        private int X { get; set; }
        private int Y { get; set; }
        private int MapX { get; set; }
        private int MapY { get; set; }
        private EnumDirGhost GhostDir { get; set; }
        private bool Active { get; set; }
        private bool ShowPoints { get; set; }
        private int ShowPointsTimer { get; set; }
        private int ShowPointsX { get; set; }
        private int ShowPointsY { get; set; }
        private bool Chase { get; set; }
        
        private Point PreviousPos;

        /// <summary>
        /// Ghost Constructor
        /// </summary>
        /// <param name="GhostX"></param>
        /// <param name="GhostY"></param>
        /// <param name="GhostMapX"></param>
        /// <param name="GhostMapY"></param>
        /// <param name="GhostChase"></param>
        /// <param name="GhostActive"></param>
        public ClassGhost(int GhostX, int GhostY, int GhostMapX, int GhostMapY, bool GhostChase, bool GhostActive)
        {
            X = GhostX;
            Y = GhostY;
            MapX = GhostMapX;
            MapY = GhostMapY;
            // True si le fantôme cout aprés la Pcman 
            Chase = GhostChase;
            // True si le fantôme est actif
            Active = GhostActive;
            // Charge les images en ressources
            ListGhostUP = new List<Bitmap>()
            {
                Properties.Resources.GhostOrangeUP,
                Properties.Resources.GhostRedUP,
                Properties.Resources.GhostCyanUP,
                Properties.Resources.GhostPinkUP
            };
            ListGhostDown = new List<Bitmap>()
            {
                Properties.Resources.GhostOrangeDown,
                Properties.Resources.GhostRedDown,
                Properties.Resources.GhostCyanDown,
                Properties.Resources.GhostPinkDown
            };
            ListGhostLeft = new List<Bitmap>()
            {
                Properties.Resources.GhostOrangeLeft,
                Properties.Resources.GhostRedLeft,
                Properties.Resources.GhostCyanLeft,
                Properties.Resources.GhostPinkLeft
            };
            ListGhostRight = new List<Bitmap>()
            {
                Properties.Resources.GhostOrangeRight,
                Properties.Resources.GhostRedRight,
                Properties.Resources.GhostCyanRight,
                Properties.Resources.GhostPinkRight
            };
            GhostBlue = Properties.Resources.GhostBlue;
            // on enlève les fonds des bitmaps
            for (int i = 0; i <= 3; i++)
            {
                ListGhostUP[i].MakeTransparent(Color.Black);
                ListGhostDown[i].MakeTransparent(Color.Black);
                ListGhostLeft[i].MakeTransparent(Color.Black);
                ListGhostRight[i].MakeTransparent(Color.Black);
            }
            GhostBlue.MakeTransparent(Color.Black);
        }

        /// <summary>
        /// Calcule la distance dans les 4 directions jusquà un mur et choisit le meilleur chemin
        /// </summary>
        /// <param name="ListMaps"></param>
        /// <param name="PosGhost"></param>
        /// <returns></returns>
        public EnumDirGhost Decide(List<string> ListMaps, Point PosGhost)
        {
            int Dx, Dy, H;
            List<int> ListDistances = new List<int>();
            List<EnumDirGhost> ListDirections = new List<EnumDirGhost>();
            // Calcule distance dans les 4 directions entre le fantôme et un mur
            // Right
            Dx = Math.Abs(MapX + 1 - PosGhost.X);
            Dy = Math.Abs(MapY - PosGhost.Y);
            H = ListMaps[MapY].Substring(MapX, 1) == "W" ? 100000 : 0;
            if (PreviousPos == new Point(MapX + 1, MapY))
                H += 1000;
            ListDistances.Add(Dx + Dy + H);
            ListDirections.Add(EnumDirGhost.Right);
            // Left
            Dx = Math.Abs(MapX - 1 - PosGhost.X);
            Dy = Math.Abs(MapY - PosGhost.Y);
            H = ListMaps[MapY].Substring(MapX - 2, 1) == "W" ? 100000 : 0;
            if (PreviousPos == new Point(MapX - 1, MapY))
                H += 1000;
            ListDistances.Add(Dx + Dy + H);
            ListDirections.Add(EnumDirGhost.Left);
            // Up
            Dx = Math.Abs(MapX - PosGhost.X);
            Dy = Math.Abs(MapY - 1 - PosGhost.Y);
            H = ListMaps[MapY - 1].Substring(MapX - 1, 1) == "W" ? 100000 : 0;
            if (PreviousPos == new Point(MapX, MapY - 1))
                H += 1000;
            ListDistances.Add(Dx + Dy + H);
            ListDirections.Add(EnumDirGhost.Up);
            // Down
            Dx = Math.Abs(MapX - PosGhost.X);
            Dy = Math.Abs(MapY + 1 - PosGhost.Y);
            H = ListMaps[MapY + 1].Substring(MapX - 1, 1) == "W" ? 100000 : 0;
            if (PreviousPos == new Point(MapX, MapY + 1))
                H += 1000;
            ListDistances.Add(Dx + Dy + H);
            ListDirections.Add(EnumDirGhost.Down);
            // décide le meilleur chemin
            PreviousPos = new Point(MapX, MapY);
            return ListDirections[ListDistances.FindIndex(p => p == ListDistances.Min())];
        }

        /// <summary>
        /// Dessine le fantôme
        /// </summary>
        /// <param name="Destination"></param>
        /// <param name="Dir"></param>
        /// <param name="GhostColor"></param>
        public void DrawGhostSprite(Graphics Destination, EnumDirGhost Dir, int GhostColor)
        {
            Bitmap BitmapGhost = null;
            if (GhostColor < 4)
                switch (Dir)
                {
                    case EnumDirGhost.Right:
                        BitmapGhost = new Bitmap(ListGhostRight[GhostColor]);
                        break;
                    case EnumDirGhost.Left:
                        BitmapGhost = new Bitmap(ListGhostLeft[GhostColor]);
                        break;
                    case EnumDirGhost.Up:
                        BitmapGhost = new Bitmap(ListGhostUP[GhostColor]);
                        break;
                    case EnumDirGhost.Down:
                        BitmapGhost = new Bitmap(ListGhostDown[GhostColor]);
                        break;
                }
            else
                BitmapGhost = new Bitmap(GhostBlue);
            Destination.DrawImage(BitmapGhost, new Rectangle(X, Y, 25, 25), 0, 0, 25, 25, GraphicsUnit.Pixel);
            BitmapGhost.Dispose();
        }

        /// <summary>
        /// Définit la direction
        /// </summary>
        /// <param name="GhostDirection"></param>
        public void SetMoveDir(EnumDirGhost GhostDirection)
        {
            GhostDir = GhostDirection;
        }

        /// <summary>
        /// Retourne la direction
        /// </summary>
        /// <returns></returns>
        public EnumDirGhost GetMoveDir()
        {
            return GhostDir;
        }

        /// <summary>
        /// Définit position X 
        /// </summary>
        /// <param name="GhostX"></param>
        public void SetX(int GhostX)
        {
            X = GhostX;
        }

        /// <summary>
        /// Définit position Y 
        /// </summary>
        /// <param name="GhostY"></param>
        public void SetY(int GhostY)
        {
            Y = GhostY;
        }

        /// <summary>
        /// Retourne  position X
        /// </summary>
        /// <returns></returns>
        public int GetX()
        {
            return X;
        }

        /// <summary>
        /// Retourne position Y
        /// </summary>
        /// <returns></returns>
        public int GetY()
        {
            return Y;
        }

        /// <summary>
        /// Définit position Map X
        /// </summary>
        /// <param name="GhostMapX"></param>
        public void SetMapX(int GhostMapX)
        {
            MapX = GhostMapX;
        }

        /// <summary>
        /// Définit position Map Y
        /// </summary>
        /// <param name="GhostMapY"></param>
        public void SetMapY(int GhostMapY)
        {
            MapY = GhostMapY;
        }

        /// <summary>
        /// Retourne position Map X
        /// </summary>
        /// <returns></returns>
        public int GetMapX()
        {
            return MapX;
        }

        /// <summary>
        /// Retourne position Map Y
        /// </summary>
        /// <returns></returns>
        public int GetMapY()
        {
            return MapY;
        }

        /// <summary>
        /// Retourne si fantôme en poursuite
        /// </summary>
        /// <returns></returns>
        public bool IsChaser()
        {
            return Chase;
        }

        /// <summary>
        /// Retourne si fantôme actif
        /// </summary>
        /// <returns></returns>
        public bool IsActive()
        {
            return Active;
        }

        /// <summary>
        /// Active ou non le fantôme
        /// </summary>
        /// <param name="GhostActive"></param>
        public void SetActive(bool GhostActive)
        {
            Active = GhostActive;
        }

        /// <summary>
        /// Active ou désactive visu points
        /// </summary>
        /// <param name="GhostShowPoints"></param>
        public void SetShowPoints(bool GhostShowPoints)
        {
            ShowPoints = GhostShowPoints;
        }

        /// <summary>
        /// Retourne si les points sont visibles
        /// </summary>
        /// <returns></returns>
        public bool IsShowingPoints()
        {
            return ShowPoints;
        }

        /// <summary>
        /// Valeur pour le timer points fantôme
        /// </summary>
        /// <param name="Val"></param>
        public void SetPointsTimer(int Val)
        {
            ShowPointsTimer = Val;
        }

        /// <summary>
        /// Retourne la valeur du timer points fantôme
        /// </summary>
        /// <returns></returns>
        public int GetPointsTimer()
        {
            return ShowPointsTimer;
        }

        /// <summary>
        /// Définit la position X des points fantôme
        /// </summary>
        /// <param name="X"></param>
        public void SetShowPointsX(int X)
        {
            ShowPointsX = X;
        }

        /// <summary>
        /// Retourne la position X des points fantôme
        /// </summary>
        /// <returns></returns>
        public int GetPointsX()
        {
            return ShowPointsX;
        }

        /// <summary>
        /// Définit la position X des points fantôme
        /// </summary>
        /// <param name="Y"></param>
        public void SetShowPointsY(int Y)
        {
            ShowPointsY = Y;
        }

        /// <summary>
        /// Retourne la position Y des points fantôme
        /// </summary>
        /// <returns></returns>
        public int GetPointsY()
        {
            return ShowPointsY;
        }
    }
}
